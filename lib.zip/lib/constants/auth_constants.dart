//import 'package:flutter_dotenv/flutter_dotenv.dart';

class AuthConstants {
  //static String get apiKey => dotenv.env['SUPABASE_URL'] ?? '';
  //static String get projectUrl => dotenv.env['SUPABASE_ANON_KEY'] ?? '';
  static const String projectUrl = "https://ccaqaarhhdpqjxcotuxc.supabase.co";
  static const String apiKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNjYXFhYXJoaGRwcWp4Y290dXhjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc2OTA3MTEsImV4cCI6MjA4MzI2NjcxMX0.DTudgFdtIu97FZvEF1lnu3lBQxUdOLNZbWjSmY__ZAg";
}