import 'base_ocr_viewmodel.dart';

class PrintedTextViewModel extends BaseOcrViewModel {
  PrintedTextViewModel ({required super.recognizeTextUseCase});
}