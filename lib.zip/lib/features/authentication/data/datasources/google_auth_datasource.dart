import 'package:flutter/foundation.dart' show kIsWeb, debugPrint;
import 'package:google_sign_in/google_sign_in.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class GoogleAuthDatasource {
  /// Web Client ID (à configurer aussi dans web/index.html)
  static const String _webClientId = '35039953060-2ftqbtc1ruqescq3mb5jrbpn7rvi98rj.apps.googleusercontent.com';

  /// iOS Client ID (null si Android uniquement)
  static const String? _iosClientId = null;

  static const List<String> _scopes = ['email', 'profile'];

  final GoogleSignIn _googleSignIn = GoogleSignIn.instance;
  bool _isInitialized = false;

  /// Initialise GoogleSignIn selon la plateforme
  Future<void> _ensureInitialized() async {
    if (_isInitialized) return;

    if (kIsWeb) {
      // Configuration Web : le Client ID doit être dans web/index.html
      // <meta name="google-signin-client_id" content="...">
      await _googleSignIn.initialize();
    } else {
      // Configuration Android/iOS
      await _googleSignIn.initialize(
        serverClientId: _webClientId, // Web Client ID pour Android
        clientId: _iosClientId, // iOS Client ID si nécessaire
      );
    }

    _isInitialized = true;
  }

  /// Authentification Google avec Supabase
  Future<AuthResponse> signInWithGoogle() async {
    try {
      debugPrint('🚀 [GoogleAuth] Début authentification');

      // 1. Initialiser selon la plateforme
      await _ensureInitialized();
      debugPrint('✅ [GoogleAuth] Initialisation OK');

      // 2. Authentifier l'utilisateur
      debugPrint('🔐 [GoogleAuth] Appel authenticate()...');
      final googleUser = await _googleSignIn.authenticate();
      debugPrint('✅ [GoogleAuth] Utilisateur authentifié: ${googleUser.email}');

      // 3. Obtenir les tokens selon la plateforme
      String? idToken;
      String? accessToken;

      if (kIsWeb) {
        debugPrint('🌐 [GoogleAuth] Flux Web - récupération tokens');
        final authorization = await googleUser.authorizationClient
            .authorizationForScopes(_scopes) ??
            await googleUser.authorizationClient.authorizeScopes(_scopes);

        idToken = googleUser.authentication.idToken;
        accessToken = authorization.accessToken;
        debugPrint('✅ [GoogleAuth] Tokens Web obtenus');
      } else {
        debugPrint('📱 [GoogleAuth] Flux Android - récupération tokens');

        // Méthode 1: Essayer avec idToken direct
        idToken = googleUser.authentication.idToken;
        debugPrint('🔑 [GoogleAuth] idToken: ${idToken?.substring(0, 20)}...');

        if (idToken == null) {
          debugPrint('⚠️ [GoogleAuth] Pas de idToken, tentative avec serverAuthCode');

          // Méthode 2: Essayer avec serverAuthCode
          final serverAuth = await googleUser.authorizationClient
              .authorizeServer(_scopes);

          if (serverAuth?.serverAuthCode != null) {
            debugPrint('🔑 [GoogleAuth] serverAuthCode: ${serverAuth!.serverAuthCode!.substring(0, 20)}...');
            idToken = serverAuth.serverAuthCode;
          }
        }

        // Essayer d'obtenir l'accessToken
        try {
          final authorization = await googleUser.authorizationClient
              .authorizationForScopes(_scopes);
          accessToken = authorization?.accessToken;
          debugPrint('🔑 [GoogleAuth] accessToken: ${accessToken?.substring(0, 20)}...');
        } catch (e) {
          debugPrint('⚠️ [GoogleAuth] Pas d\'accessToken: $e');
        }
      }

      // 4. Vérifier qu'on a au moins un idToken
      if (idToken == null) {
        throw const AuthException('Pas de ID Token ni serverAuthCode trouvé');
      }

      // 5. Authentifier avec Supabase
      debugPrint('📤 [GoogleAuth] Envoi à Supabase...');
      final SupabaseClient client = Supabase.instance.client;
      final response = await client.auth.signInWithIdToken(
        provider: OAuthProvider.google,
        idToken: idToken,
        accessToken: accessToken,
      );

      debugPrint('✅ [GoogleAuth] Authentification Supabase réussie!');
      return response;
    } on AuthException catch (e) {
      debugPrint('❌ [GoogleAuth] AuthException: $e');
      rethrow;
    } catch (e, stackTrace) {
      debugPrint('❌ [GoogleAuth] Erreur: $e');
      debugPrint('📋 [GoogleAuth] StackTrace: $stackTrace');
      throw AuthException('Erreur Google Sign-In: $e');
    }
  }

  /// Déconnexion Google
  Future<void> signOut() async {
    await _googleSignIn.signOut();
    _isInitialized = false;
  }
}
